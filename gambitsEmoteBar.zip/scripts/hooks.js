import { handleHook, endEmoteEffects, endAllEmoteEffects } from './utils.js';
import { packageId } from "./constants.js";

export function registerHooks() {
  Hooks.on("preUpdateCombat", (combat, update, options) => {
    if(!game.user.isGM) return;

    const emoteTriggers = game.settings.get(packageId, "emoteTriggers") || {};
    const hasHook = Object.values(emoteTriggers).some(triggerList =>
      triggerList.some(trigger => trigger.hook === "combatStart" || trigger.hook === "combatEnd" || trigger.hook === "roundStart" || trigger.hook === "turnStart")
    );
    if(!hasHook) return;

    foundry.utils.setProperty(options, "flags.gambitsEmoteBar.prevStarted", combat.started);
    foundry.utils.setProperty(options, "flags.gambitsEmoteBar.prevRound", combat.round ?? 0);
    foundry.utils.setProperty(options, "flags.gambitsEmoteBar.prevTurn", combat.turn  ?? 0);
  });

  Hooks.on("preDeleteToken", async (tokenDoc, _options) => {
    await endAllEmoteEffects([tokenDoc?.object]);
  });

  Hooks.on("updateCombat", (combat, update, options) => {
    if (!game.user.isGM) return;

    const emoteTriggers = game.settings.get(packageId, "emoteTriggers") || {};
    const hasHook = Object.values(emoteTriggers).some(triggerList =>
      triggerList.some(trigger => trigger.hook === "combatStart" || trigger.hook === "combatEnd" || trigger.hook === "roundStart" || trigger.hook === "turnStart")
    );
    if(!hasHook) return;

    const prevStarted = foundry.utils.getProperty(options, "flags.gambitsEmoteBar.prevStarted");
    const prevRound = foundry.utils.getProperty(options, "flags.gambitsEmoteBar.prevRound");
    const prevTurn = foundry.utils.getProperty(options, "flags.gambitsEmoteBar.prevTurn");

    if (combat.started && !prevStarted) handleHook("combatStart", combat);
    if (!combat.started && prevStarted) handleHook("combatEnd", combat);

    if (typeof update.round === "number" && update.round !== prevRound) {
      handleHook("roundStart", combat);
    }

    if (typeof update.turn === "number" && update.turn !== prevTurn) {
      handleHook("turnStart", combat);
    }
  });

  Hooks.on("createCombatant", (combatant, options, userId) => {
    if (!game.user.isGM) return;

    const emoteTriggers = game.settings.get(packageId, "emoteTriggers") || {};
    const hasHook = Object.values(emoteTriggers).some(triggerList =>
      triggerList.some(trigger => trigger.hook === "combatantEnter")
    );
    if(!hasHook) return;

    if (game.combat?.started) handleHook("combatantEnter", combatant);
  });

  Hooks.on("dnd5e.restCompleted", (actor, restData) => {
    if(!game.user.isGM) return;

    const emoteTriggers = game.settings.get(packageId, "emoteTriggers") || {};
    const hasHook = Object.values(emoteTriggers).some(triggerList =>
      triggerList.some(trigger => trigger.hook === "restLong" || trigger.hook === "restShort")
    );
    if(!hasHook) return;

    if (restData.type === "long") {
      handleHook("restLong", actor);
    }
    else if (restData.type === "short") {
      handleHook("restShort", actor);
    }
  });

  Hooks.on('updateActor', async (actor, diff, options, userID) => {
    if(!game.user.isGM) return;

    const token = actor.getActiveTokens()?.[0];
    if (!token) return;
    const emoteTriggers = game.settings.get(packageId, "emoteTriggers") || {};
    const thresholdTriggers = Object.entries(emoteTriggers).flatMap(([emoteName, triggers]) => {
      return triggers
        .filter(t => t.hook === "hpPercentage")
        .map(t => ({
          emote:     emoteName,
          threshold: t.threshold ?? 50
        }));
    });
    if (!thresholdTriggers.length) return;

    if (!diff.system?.attributes?.hp) return;

    const hpCurr    = actor.system.attributes.hp.value;
    const hpMax     = actor.system.attributes.hp.max;
    if (!hpMax) return;
    const currPct   = (hpCurr / hpMax) * 100;

    for (const { emote, threshold } of thresholdTriggers) {
      const effectName = `emoteBar${emote}_${token.id}_${game.gambitsEmoteBar.dialogUser}`;
      const effect = Sequencer.EffectManager.getEffects({ name: effectName, object: token });

      if ((currPct < threshold) && !effect.length) {
        handleHook("hpPercentage", actor);
      }
      else if ((currPct >= threshold) && effect.length > 0) {
        if (!token) continue;
        endEmoteEffects(emote, [token]);
      }
    }
  });
}
